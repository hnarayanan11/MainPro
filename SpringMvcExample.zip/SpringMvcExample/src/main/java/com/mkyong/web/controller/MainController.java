package com.mkyong.web.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.mkyong.web.domain.PersonChar;
import com.mkyong.web.domain.Tag;
import com.sample.Constants;

@Controller
public class MainController {

	List<Tag> data = new ArrayList<Tag>();
	List<String> story = new ArrayList<String>();
	List<String> pronouns = new ArrayList<String>();
	List<String> tense = new ArrayList<String>(); 

	MainController() {

	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView getPages() {

		ModelAndView model = new ModelAndView("example");
		return model;

	}

	@RequestMapping(value = "/getTags", method = RequestMethod.GET)
	public @ResponseBody
	List<Tag> getTags(@RequestParam(value = "tagName", required = false) String tagName, @RequestParam(value = "name1", required = false) String name1,
			@RequestParam(value = "name2", required = false) String name2, @RequestParam(value = "name3", required = false) String name3,
			@RequestParam(value = "pronoun1", required = false) String pronoun1, @RequestParam(value = "pronoun2", required = false) String pronoun2,
			@RequestParam(value = "pronoun3", required = false) String pronoun3) {

		return simulateSearchResult(tagName,constructPersonList(name1, name2, name3, pronoun1, pronoun2, pronoun3));

	}

	private List<PersonChar> constructPersonList(String name1, String name2, String name3, String pronoun1,
			String pronoun2, String pronoun3) {
		List<PersonChar> personList = new ArrayList<PersonChar>();
		personList.add(new PersonChar(name1, pronoun1));
		if(!name2.equals("")) personList.add(new PersonChar(name2, pronoun2));
		if(!name3.equals("")) personList.add(new PersonChar(name3, pronoun3));
		return personList;
	}

	private List<Tag> simulateSearchResult(String tagName, List<PersonChar> personlist) {
		List<Tag> result = new ArrayList<Tag>();
		if(endOfLine(tagName)){
			/*Get the Last Statement*/
			if(tagName.split(".").length > 0){
				tagName = tagName.split(".")[0];
			}
			/* 1. Find Pronoun and Tense
			 * 2. Construct statements*/		
			result = generateStatements(personlist, tagName);		
		}else{
			result = generateStatements(personlist, tagName);
		}
		return result;
	}

	private List<Tag> generateStatements(List<PersonChar> personlist, String tagName) {
		data =  new ArrayList<Tag>();		
		for(int i = 0; i < 5; i++){
			int idx = new Random().nextInt(Constants.SAMPLE_STS.size());
			String statement = Constants.SAMPLE_STS.get(idx);
			String completeSts = getCompleteStatement(statement,personlist);
			if (completeSts.contains(tagName)) {
				data.add(new Tag(i, completeSts));
			}
		}		
		return data;
	}

	private String getCompleteStatement(String statement, List<PersonChar> personlist) {
		HashSet<String> stsPronouns = getPronouns(statement);
		Iterator iterator = stsPronouns.iterator();
		List<String> pronounList = getPronounList(personlist);
		while(iterator.hasNext()){
			int idx = new Random().nextInt(pronounList.size());
			String pronoun =pronounList.get(idx);
			statement = statement.replace(iterator.next().toString(), pronoun);
		};
		return statement;
	}

	private List<String> getPronounList(List<PersonChar> personlist) {
		List<String> pronounList = new ArrayList<String>();
		for(PersonChar p:personlist){
			pronounList.add(p.getPronoun());
		}
		return pronounList;
	}

	private HashSet<String> getPronouns(String statement) {
		String [] wordList = statement.split(" ");
		HashSet<String> pronouns = new HashSet<String>();
		for(String data : wordList){
			if(data.contains("PRONOUN")){
				pronouns.add(data);
			}
		}
		return pronouns;
	}

	private boolean endOfLine(String tagName) {
		if(tagName.substring(tagName.trim().length()-1).equalsIgnoreCase(".")){
			return true;
		}else{
			return false;
		}
	}

}
