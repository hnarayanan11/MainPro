package com.mkyong.web.domain;

public class PersonChar {

	private String name;
	
	private String pronoun;	

	public PersonChar(String name, String pronoun) {
		super();
		this.name = name;
		this.pronoun = pronoun;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPronoun() {
		return pronoun;
	}

	public void setPronoun(String pronoun) {
		this.pronoun = pronoun;
	}
	
	
}
