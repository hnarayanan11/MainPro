package com.sample;

import java.util.List;
import java.util.Arrays;

public class Constants {

	public static List<String> SAMPLE_STS = Arrays.asList("Once upon a time... there was a PRONOUN_3 .",
			"The PRONOUN_3 said not to go outside. ",
			"The PRONOUN_3 went outside. ",
			"The PRONOUN_3 heard about the PRONOUN_4 .",
			"The PRONOUN_4 scared the PRONOUN_3 . ",
			"The PRONOUN_4 kidnapped the PRONOUN_3 .",
			"The PRONOUN_5 entered. ",
			"The PRONOUN_5 and the PRONOUN_4 fought.",
			"The PRONOUN_5 won the fight. ",
			"The PRONOUN_5 solved the problem of the PRONOUN_3.", "The PRONOUN_5 returned. ",
			"A big treasure to the PRONOUN_5 .", "The PRONOUN_1 and the PRONOUN_6 talked",
			"The PRONOUN_1 fell in the trap of the PRONOUN_2 .", "The PRONOUN_2 scared the PRONOUN_1 . ",
			"The PRONOUN_2 used a magic spell against the PRONOUN_1 .",
			"Others and the PRONOUN_6 heard about the PRONOUN_2 . ", "The PRONOUN_6 heard something. ",
			"The PRONOUN_2 heard about the PRONOUN_6 .", "The PRONOUN_6 shared information with others.",
			"The PRONOUN_5 departed.", "The PRONOUN_5 fell in the trap.", "The PRONOUN_2 enchanted the PRONOUN_5 .",
			"The PRONOUN_1 returned.");

	public static List<String> PRONOUNS_MALE = Arrays.asList("boy", "prince", "king", "man");
	
	public static List<String> PRONOUNS_FEMALE = Arrays.asList("girl", "princess", "queen", "women");
	
	public static List<String> PRONOUNS_GENERAL = Arrays.asList("wizard", "animal", "cow", "goat", "donkey");
	
	public static List<String> PRONOUNS_ALL = Arrays.asList("boy", "prince", "king", "man", "wizard", "girl", "princess", "queen", "women", "animal", "cow", "goat", "donkey");
	
}
